package com.codegym.register_validate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterValidateApplicationTests {

	@Test
	void contextLoads() {
	}

}
